#ifndef __FUNCTION_H__
#define __FUNCTION_H__

#include "gpio.h"
#include "delay.h"



void sys_alarm_on(void);
void sys_alarm_off(void);

void transmit_onenet(void);
void receive_onenet(void);
void CO_exceeding_of_concentration(void) ;
//#define alarm_on sys_alarm_on () 
//#define alarm_off sys_alarm_off () 

#endif
