


#include "function.h"
#include "esp8266.h"
#include "usart.h"
#include "dht11.h"
#include "onenet.h"
#include "delay.h"
#include "adc.h"
void sys_alarm_on(void)
{

HAL_GPIO_WritePin(GPIOB, GPIO_PIN_14|GPIO_PIN_15|GPIO_PIN_5, GPIO_PIN_SET);

}

void sys_alarm_off(void)
{


HAL_GPIO_WritePin(GPIOB, GPIO_PIN_14|GPIO_PIN_15|GPIO_PIN_5, GPIO_PIN_RESET);

}
	

void CO_exceeding_of_concentration(void)
{

	 printf3("alarm_Num:%f\r\n", alarm_num_judge/1000.0);
   if(Get_ADCValue_MQ7()> alarm_num_judge/1000.0)
	 {
		sys_alarm_on () ;
	 }
	else sys_alarm_off () ;
}


void transmit_onenet(void)  //����ƽ̨��app����������
{
		if(++timeCount >= 15)									//���ͼ��5s
		{
			printf3("OneNet_SendData\r\n");	
			OneNet_SendData();									//��������
			timeCount = 0;
			ESP8266_Clear();
//      printf3("Humidity:%d\r\n",dht11_info.humidity) ;
//		  printf3("Tempreture:%d\r\n", dht11_info.tempreture) ;
		}		

}

void receive_onenet(void)   //������ƽ̨��app����������
{

			dataPtr = ESP8266_GetIPD(0);
	  	if(dataPtr != NULL)
			OneNet_RevPro(dataPtr);
			
}
