#ifndef DHT11_H
#define DHT11_H

#include "sys.h"

//PB5
#define DHT11_IO_IN()  {GPIOB->CRL&=0XFF0FFFFF;GPIOB->CRL|=8<<20;}
#define DHT11_IO_OUT() {GPIOB->CRL&=0XFF0FFFFF;GPIOB->CRL|=3<<20;} 
//IO��������   
#define	DHT11_DQ_OUT PBout(5)
#define	DHT11_DQ_IN  PBin(5) 


//extern u8 temp;
//extern u8 humi;


typedef struct
{

	u8 tempreture;
	u8 humidity;

} DHT11_INFO;

extern DHT11_INFO dht11_info;



u8 DHT11_Init(void);//��ʼ��DHT11
u8 DHT11_Read_Data(void);//��ȡ����
u8 DHT11_Read_Byte(void);//��ȡһ���ֽ�
u8 DHT11_Read_Bit(void);//��ȡһλ
u8 DHT11_Check(void);//���DHT11
void DHT11_Rst(void);//��λDHT11   

#endif
